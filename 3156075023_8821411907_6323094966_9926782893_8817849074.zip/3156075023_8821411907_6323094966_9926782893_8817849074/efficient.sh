#!/bin/bash
python3 efficient.py "$1" "$2"